# -*- coding: utf-8 -*-
# @Time : 2025/7/10 20:56
# @Author : Lukax
# @Email : Lukarxiang@gmail.com
# @File : Utils.py
# -*- presentd: PyCharm -*-


import os
import numpy as np
import pandas as pd
from Settings import Config
from inplemental import load_data
from Utils import set_seed, train2compare_outlier_strategy, print_strategy_comparison, analyze_outliers, train_mlp_model, create_multiple_submissions, save2csv



def flow():
    Config.print_config_summary()

    set_seed(Config.RANDOM_STATE)
    train, test, submission = load_data()
    print(f"\ntrain shape: {train.shape}\ntest shape: {test.shape}")

    if train[Config.TARGET].isnull().any():
        print(f"target has {train[Config.TARGET].isnull().sum()} NA.")

    analyze_outliers(train) # 单纯的异常值数量检测
    
    # ML single training
    single_oof_pred, single_test_pred, single_strategy_res, single_best_strategy, single_best_combination = train2compare_outlier_strategy(train, test, mode = 'single')
    print(f"{'='*50}\n\tsingle best: {single_best_combination}")

    # ML ensemble training
    ensemble_oof_pred, ensemble_test_pred, ensemble_strategy_res, ensemble_best_strategy, ensemble_best_combination = train2compare_outlier_strategy(train, test, mode = 'ensemble')
    print(f"{'='*50}\n\tensemble best: {ensemble_best_combination}")

    # strategy comparison
    print_strategy_comparison(single_strategy_res, 'single', single_best_combination)
    print_strategy_comparison(ensemble_strategy_res, 'ensemble', ensemble_best_combination)
    
    single_best_score = single_strategy_res[single_best_strategy]['ensemble_score']
    ensemble_best_score = ensemble_strategy_res[ensemble_best_strategy]['ensemble_score']
    if ensemble_best_score > single_best_score: # 比较选出 单模型 和 集成模型 中更好的
        final_ml_pred, final_ml_strategy = ensemble_test_pred, ensemble_best_combination
        final_ml_score, strategy_type = ensemble_best_score, "ensemble ml"
    else:
        final_ml_pred, final_ml_strategy = single_test_pred, single_best_combination
        final_ml_score, strategy_type = single_best_score, "single ml"
    print(f"{'='*50}\n\tBest ML strategy: {strategy_type} - {final_ml_strategy}\nBest score: {final_ml_score:.6f}")


    # DL mlp
    mlp_predictions, mlp_score = train_mlp_model(train, test)
    print(f"{'='*50}\n\tMLP score: {mlp_score:.5f}")

    # generate submission
    if mlp_predictions is not None: # mlp和最好的 ml模型进行集成制作 submission
        best_predictions, best_filename = create_multiple_submissions(
            train, final_ml_pred, mlp_predictions, submission,
            final_ml_strategy.replace(' ', '_').lower(), final_ml_score, mlp_score)
    else: # ML only
        submission[Config.TARGET] = final_ml_pred
        best_filename = f"submission_{final_ml_strategy.replace(' ', '_').lower()}_{final_ml_score:.6f}.csv"
        best_filepath = os.path.join(Config.SUBMISSION_DIR, best_filename)
        submission.to_csv(best_filepath, index = False)
        print(f"ML submission saved to {best_filepath}")
        best_predictions, final_score = final_ml_pred, final_ml_score
    print(best_predictions, '\n', best_filename, '\n', final_score)

    # summary analysis
    results_summary = {
        'ml_single_best': {'strategy': single_best_combination, 'score': single_best_score},
        'ml_ensemble_best': {'strategy': ensemble_best_combination, 'score': ensemble_best_score},
        'ml_final': {'strategy': final_ml_strategy, 'score': final_ml_score, 'type': strategy_type},
        'mlp_score': mlp_score if mlp_predictions is not None else 'N/A',
        'best_filename': best_filename
    }
    results_df = pd.DataFrame([results_summary])
    summary_filepath = os.path.join(Config.RESULTS_DIR, 'comprehensive_results_summary.csv')
    results_df.to_csv(summary_filepath, index = False)



if __name__ == "__main__":
    flow()


