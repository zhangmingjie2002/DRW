## Kaggle ML model (version 1.0)
参考 sub-sample-vs-super-sample-noisy-rows.ipynb的主要训练流程，以此基础上，拓展了
- ML 单模型种类
- ML 单模型的参数搜索
- ML 多模型集成的权重搜索
等功能，并让整个工作流完整化。

还需补充方向：
- 特征的选择（已有 feature_engineering.ipynb可参考，需搜集其他思路）
- MLP的参数搜索

### 模块介绍
模型参数搜索: optimize_params + HyperparameterOptimizer
策略集成工作流： main + Utils + inplemental
相关配置文件： Settings


### 环境安装
如果自己习惯 conda环境，可以直接按照 pyproject.toml中的依赖进行自行安装，略过下面的内容

下面介绍一种简单快速的环境安装方法 UV
1. 安装 uv工具 https://github.com/astral-sh/uv
    windows powershell：powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
    macOS terminal：curl -LsSf https://astral.sh/uv/install.sh | sh

2. powershell 进入项目
    uv python install 3.11
    uv sync

    如果是 windows且已经安装了 cuda，执行 setup_cuda.py，卸载 cpu版本的 torch，安装 gpu版本的 torch
    .venv/bin/activate
    python setup_cuda.py
    安装验证
    python -c "import torch; print(f'PyTorch: {torch.__version__}'); print(f'CUDA: {torch.cuda.is_available()}')"
    安装的 gpu版本 torch需要参考本机安装的 cuda版本来进行选择


